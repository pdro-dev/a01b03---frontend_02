// let li = document.getElementById('item1')
// console.log(li.innerText)

// let divs = document.querySelectorAll(".conteudo")
// console.log(divs)

// let articles = document.querySelectorAll("article")
// console.log(articles)

let e = document.querySelector("section article:nth-child(5) > h2")
console.log(e)